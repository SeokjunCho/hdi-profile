// @ts-nocheck
/* eslint-disable no-undef */
/* eslint-disable no-console */
sap.ui.define(["./BaseController"], function (Controller) {
    "use strict";
    return Controller.extend("com.hdi.myProfile.controller.NotFound", {
        onInit: function () {
            // console.log("Not Found");
        },
    });
});
